﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RP3_dz2
{
    public partial class PetriDishControl : UserControl
    {
        //...........podaci...........
        private int playerpoints;
        private int pointsaddedperround;

        //...........path...............
        private string path;

        //event handler za bakterije neke vr
        public event EventHandler<Bacteria> kupljeno;

        //konstruktor
        public PetriDishControl()
        {
            InitializeComponent();
        }

        //logistika
        private void buyClicked(object sender, EventArgs e)
        {
            //ako u igri ima manje bodova nego sto je cijena bakterij, vrati
            if (playerpoints < cijena) return;

            //ako nije, kupi bakteriju
            koliko += 1;
            //ako je kolonija bakterija bila prazna, lupi novu bakteriju u nju
            if (kupljeno != null)
                kupljeno(sender, new Bacteria { Price = cijena, HowMany = koliko, Name = base.Name, Points = playerpoints });

        }



        //..............................svojstva......................
        public string ime
        {
            set { nameLabel.Text = "Species name: " + value; }
            get { return nameLabel.Text; }
        }

        public int koliko
        {
            set { howmanyLabel.Text = "Number of: " + value.ToString(); }
            get { return int.Parse(howmanyLabel.Text.Split(' ')[2]); }
        }

        public int cijena
        {
            set { priceLabel.Text = "Price: " + value.ToString(); }
            get { return int.Parse(priceLabel.Text.Split(' ')[1]); }
        }

        public int bodova
        {
            set { playerpoints = value; }
        }

        public int PointsAddedPerRound
        {
            set { pointsaddedperround = value; }
            get { return pointsaddedperround; }
        }


        public Bitmap addImage
        {
            set { BacteriaPictureBox.Image = value; }
        }

        public string putanja
        {
            set
            { BacteriaPictureBox.Image = Image.FromFile(value); }
        }

    }
}
