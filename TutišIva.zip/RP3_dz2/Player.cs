﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RP3_dz2
{
    class Player
    {
        private int broj_bodova;

        //konstruktor
        public Player()
        {
            broj_bodova = 0;
        }

        //.......................logistika...........

        public void incrementPoints(int b)
        {
            broj_bodova+=b;
        }

        public void decrementPoints(int b) 
        {
            broj_bodova -= b;
        }

        public void reset()
        {
            broj_bodova = 0;
        }

        //.........................svojstva...............
        public int Broj_Bodova 
        {
            get { return broj_bodova; }
            set { broj_bodova = value; }
        }
    }
}
