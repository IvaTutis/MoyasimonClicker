﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RP3_dz2
{

    public partial class Form1 : Form
    {
        //bodovi
        Player p;

        //usercontrol
        PetriDishControl GreenFungiControl;
        PetriDishControl OryzaeControl;
        PetriDishControl CladosporiumControl;

        //flags
        bool oryzae;
        bool cladosporium;
        bool greenfungi;

        public Form1()
        {
            InitializeComponent();
        }

        //funkcija koja (re)inicijalizira igru
        private void Form1_Load(object sender, EventArgs e)
        {
            //forma
            this.Width = 900;
            this.Height = 500;
            splitContainer1.SplitterDistance = 200;
            splitContainer2.SplitterDistance = 400;

            //inicijaliziram igraca
            p = new Player();

            //inicijaliziram kontrole
            GreenFungiControl = new PetriDishControl();
            OryzaeControl = new PetriDishControl();
            CladosporiumControl = new PetriDishControl();

            //inicijaliziram zastavice
            oryzae = false;
            greenfungi = false;
            cladosporium = false;


            //imena
            GreenFungiControl.ime = "Green Fungi";
            OryzaeControl.ime = "Oryzae";
            CladosporiumControl.ime = "Claudosporium";

            //koliko bodova dodaju
            GreenFungiControl.PointsAddedPerRound = 5;
            OryzaeControl.PointsAddedPerRound = 10;
            CladosporiumControl.PointsAddedPerRound = 15;

            //inicijaliziram koliko one registriraju da ima ukupno bodova u igri
            GreenFungiControl.bodova = 0;
            CladosporiumControl.bodova = 0;
            OryzaeControl.bodova = 0;

            //updateam cijene
            GreenFungiControl.cijena = 5;
            OryzaeControl.cijena = 10;
            CladosporiumControl.cijena = 20;

            //updateam koliko ih ima 
            GreenFungiControl.koliko = 0;
            OryzaeControl.koliko = 0;
            CladosporiumControl.koliko = 0;


            //updateam event handlere
            GreenFungiControl.kupljeno += (_sender, _e) =>
            {

                p.Broj_Bodova -= GreenFungiControl.cijena;
                GreenFungiControl.koliko = _e.HowMany;
                GreenFungiControl.cijena += 5;

                GreenFungiControl.bodova = p.Broj_Bodova;
                writeText(_e);
            };

            CladosporiumControl.kupljeno += (_sender, _e) =>
            {

                p.Broj_Bodova -= CladosporiumControl.cijena;
                CladosporiumControl.koliko = _e.HowMany;
                CladosporiumControl.cijena += 5;

                CladosporiumControl.bodova = p.Broj_Bodova;
                writeText(_e);
            };

            OryzaeControl.kupljeno += (_sender, _e) =>
            {
                //oduzimam broj bodova
                p.Broj_Bodova -= CladosporiumControl.cijena;

                //pisem u labele
                OryzaeControl.koliko = _e.HowMany;
                OryzaeControl.cijena += 5;

                CladosporiumControl.bodova = p.Broj_Bodova;
                writeText(_e);
            };


            //.......................grafika...................
            //dodajem slike
            GreenFungiControl.addImage = Properties.Resources.green_fungi;
            OryzaeControl.addImage = Properties.Resources.orizae;
            CladosporiumControl.addImage = Properties.Resources.cladosporium;

            //stil kontrola za docking
            GreenFungiControl.Dock = DockStyle.Top;
            OryzaeControl.Dock = DockStyle.Top;
            CladosporiumControl.Dock = DockStyle.Top;

            writeText("New game. Objective: Collect Bacteria!");

        }

        //funkcija koja obradjuje stisak gumba na toolstripu
        private void NewGameClicked(object sender, EventArgs e)
        {
            splitContainer2.Panel1.Controls.Clear();
            textBox1.Text = "";

            Form1_Load(sender, e);
        }

        //-----------------------------------BODOVI KROZ VRIJEME-------------
        //funkcija koja obradjuje stisak clicker gumba
        private void ClickMeClicked(object sender, EventArgs e)
        {
            IncrementPointsBy(1);
        }

        //glavni timer igre
        private void timer1_Tick(object sender, EventArgs e)
        {
            //dodaj bodove od farmanja
            int added_points = GreenFungiControl.koliko * GreenFungiControl.PointsAddedPerRound
                                + OryzaeControl.koliko * OryzaeControl.PointsAddedPerRound
                                + CladosporiumControl.koliko * CladosporiumControl.PointsAddedPerRound;

            //updateaj bodove
            IncrementPointsBy(added_points);
        }

        //funkcija koja updatea bodove u kontrolama i labelu
        private void IncrementPointsBy(int b)
        {
            p.incrementPoints(b);

            //prosljedujem ukupan broj bodova kontrolama
            GreenFungiControl.bodova = p.Broj_Bodova;
            OryzaeControl.bodova = p.Broj_Bodova;
            CladosporiumControl.bodova = p.Broj_Bodova;

            //pisem u label isti broj bodova
            pointsLabel.Text = "Bacteria number: " + p.Broj_Bodova.ToString();
        }

        //funkcija koja updatea bodove u kontrolama i labelu
        private void DecrementPointsBy(int b)
        {
            p.decrementPoints(b);

            //prosljedujem ukupan broj bodova kontrolama
            GreenFungiControl.bodova = p.Broj_Bodova;
            OryzaeControl.bodova = p.Broj_Bodova;
            CladosporiumControl.bodova = p.Broj_Bodova;

            //pisem u label isti broj bodova
            pointsLabel.Text = "Bacteria number: " + p.Broj_Bodova.ToString();
        }

        //------------------------------KREIRANJE NOVE IGRE---------------

        private void writeText(Bacteria e)
        {
            DateTime dt = DateTime.Now;
            textBox1.Text += dt.ToString("hh:mm") + " " + "  New number " + e.Name + ": " + e.HowMany + Environment.NewLine;
        }

        private void writeText(string s)
        {
            DateTime dt = DateTime.Now;
            textBox1.Text += dt.ToString("hh-mm") +"  "+ s + Environment.NewLine;
        }

        private void pointsLabelChanged(object sender, EventArgs e)
        {

            //dodaj oryzae ako vec nisu
            if (!oryzae && OryzaeControl.cijena <= p.Broj_Bodova)
            {
                oryzae = true;
                splitContainer2.Panel1.Controls.Add(OryzaeControl);
            }
           
            if (!cladosporium && CladosporiumControl.cijena <= p.Broj_Bodova)
            {
                cladosporium = true;
                splitContainer2.Panel1.Controls.Add(CladosporiumControl);
            }

            if (!greenfungi && GreenFungiControl.cijena <= p.Broj_Bodova)
            {
                greenfungi = true;
                splitContainer2.Panel1.Controls.Add(GreenFungiControl);
            }
        }

    }

}

